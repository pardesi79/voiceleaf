import 'package:flutter/material.dart';
import 'app_prefs.dart';
import 'ui_text.dart';
import 'l10n.dart';

class PreferencesPage extends StatelessWidget {
  const PreferencesPage({super.key});

  static const _items = <List<String>>[
    ['dark', 'Dark Theme'],
    ['readAuto', 'Read Automatically'],
    ['screenReaderText', 'Access audiobook current page text with Screen reader'],
    ['continueBg', 'Continue Audiobook Reading when switching app or screen turned off'],
    ['processingSound', 'Processing Sound'],
    ['completeSound', 'Process Complete Indicator Sound'],
    ['pageVoice', 'Page processing voice update'],
    ['pageTurn', 'Page Turn Sound'],
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Tx('Preferences')),
      body: ListenableBuilder(
        listenable: AppPrefs.I,
        builder: (_, __) => ListView(
          children: [
            for (final it in _items)
              SwitchListTile(
                title: Tx(it[1], style: const TextStyle(fontSize: 18)),
                value: AppPrefs.I.flag(it[0]),
                onChanged: (v) => AppPrefs.I.setFlag(it[0], v),
              ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: DropdownButtonFormField<String>(
                value: AppPrefs.I.ocr,
                decoration: InputDecoration(
                    labelText: tr('Text recognition language (photos, scanned PDFs)'),
                    border: OutlineInputBorder()),
                items: const [
                  DropdownMenuItem(value: 'auto', child: Tx('Auto (detects the script)')),
                  DropdownMenuItem(value: 'latin', child: Tx('English / Latin only')),
                  DropdownMenuItem(value: 'devanagari', child: Tx('Hindi / Devanagari only')),
                  DropdownMenuItem(value: 'chinese', child: Tx('Chinese only')),
                  DropdownMenuItem(value: 'japanese', child: Tx('Japanese only')),
                  DropdownMenuItem(value: 'korean', child: Tx('Korean only')),
                ],
                onChanged: (v) {
                  if (v != null) AppPrefs.I.setOcr(v);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
